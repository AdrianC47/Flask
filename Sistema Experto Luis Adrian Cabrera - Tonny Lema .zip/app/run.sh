export FLASK_APP=Sistema.py
export FLASK_ENV=development 
flask run
